let clicks = 0;
function fun()
{
    clicks += 1;
    document.getElementById("id_btn").textContent = clicks;
}
